import numpy as np

EPSILON = np.finfo(np.float64).eps

__all__ = ["EPSILON"]
