from numpy.typing import ArrayLike, NDArray

__all__ = ["ArrayLike", "NDArray"]
